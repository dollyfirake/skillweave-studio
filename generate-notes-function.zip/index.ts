import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.7.1'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Max-Age': '86400', // 24 hours
  'Access-Control-Allow-Credentials': 'true'
};

// Helper to handle CORS preflight
const handleCors = (request: Request) => {
  if (request.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }
  return null
}

// Fetch YouTube transcript
async function fetchTranscript(videoId: string) {
  try {
    const response = await fetch(`https://youtube-transcriber.vercel.app/api/transcript?videoId=${videoId}`)
    if (!response.ok) throw new Error('Failed to fetch transcript')
    const data = await response.json()
    return data.transcript
  } catch (error) {
    console.error('Error fetching transcript:', error)
    throw new Error('Could not fetch transcript')
  }
}

// Generate notes using Hugging Face
async function generateNotes(transcript: string) {
  const apiKey = Deno.env.get('HUGGINGFACE_API_KEY')
  if (!apiKey) throw new Error('Missing Hugging Face API key')

  const prompt = `Summarize the following video transcript into key bullet points. Focus on main concepts, steps, and important details. Use markdown formatting with bullet points (-):

${transcript}`

  const response = await fetch(
    'https://api-inference.huggingface.co/models/facebook/bart-large-cnn',
    {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        inputs: prompt,
        parameters: {
          max_length: 1000,
          num_return_sequences: 1,
          temperature: 0.7,
        },
      }),
    }
  )

  if (!response.ok) {
    const error = await response.text()
    throw new Error(`Hugging Face API error: ${error}`)
  }

  const result = await response.json()
  return result[0]?.generated_text || 'No notes generated'
}

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { 
      headers: corsHeaders,
      status: 204 
    });
  }

  // Handle actual request
  try {

  try {
    const { video_id, video_title, video_description } = await req.json()
    if (!video_id) {
      return new Response(
        JSON.stringify({ error: 'Missing video_id parameter' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Get user from auth header
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    )

    // Get user
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser()
    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Check if notes already exist for this video
    const { data: existingNote, error: fetchError } = await supabaseClient
      .from('notes')
      .select('*')
      .eq('user_id', user.id)
      .eq('video_id', video_id)
      .single()

    if (existingNote && !fetchError) {
      return new Response(
        JSON.stringify({ notes: existingNote.content, fromCache: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Fetch transcript and generate notes
    const transcript = await fetchTranscript(video_id)
    const notesContent = await generateNotes(transcript)

    // Save to database
    const { data: savedNote, error: saveError } = await supabaseClient
      .from('notes')
      .upsert({
        user_id: user.id,
        video_id,
        content: { text: notesContent, generated_at: new Date().toISOString() },
      })
      .select()
      .single()

    if (saveError) {
      console.error('Error saving notes:', saveError)
      throw new Error('Failed to save notes')
    }

    return new Response(
      JSON.stringify({ notes: savedNote.content, fromCache: false }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Error in generate-notes function:', error)
    return new Response(
      JSON.stringify({ error: error.message || 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
